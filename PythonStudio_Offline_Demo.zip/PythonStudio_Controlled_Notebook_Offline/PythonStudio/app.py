"""Offline, localhost-only controlled notebook. No arbitrary browser-side Python execution."""
import json
import logging
import math
import os
import secrets
import signal
import threading
import time
from datetime import datetime
from pathlib import Path
from flask import Flask, abort, jsonify, render_template, request, send_from_directory
from modules.main_pipeline import STEPS, execute_step, suggested_dictionary

ROOT = Path(__file__).resolve().parent
for dirname in ('outputs','logs','runs'):
    (ROOT / dirname).mkdir(exist_ok=True)
app = Flask(__name__)
app.json.sort_keys = False
LOCK = threading.RLock()
RUNS = {}
SHUTDOWN_TOKEN = secrets.token_urlsafe(32)
STEP_TITLES = ['Load sample portfolio','Validate input columns','Calculate expected loss','Apply dictionary mapping','Aggregate results','Export files']

class PerRunHandler(logging.Handler):
    def __init__(self, run):
        super().__init__()
        self.run = run
        self.setFormatter(logging.Formatter('%(asctime)s | %(levelname)-7s | %(message)s','%H:%M:%S'))
    def emit(self, record):
        try:
            line = self.format(record)
            with LOCK:
                self.run['logs'].append(line)
                with (ROOT / 'logs' / (self.run['id'] + '.log')).open('a', encoding='utf-8') as f:
                    f.write(line + '\n')
        except Exception:
            self.handleError(record)

def status(run):
    context = run['context']
    previews = {}
    for key in ('df','summary'):
        if key in context:
            frame = context[key]
            previews[key] = {'columns': list(frame.columns), 'rows': json.loads(frame.head(25).to_json(orient='records')), 'count': len(frame)}
    return {'id':run['id'],'state':run['state'],'completed':sorted(run['completed']),
            'current':run['current'],'logs':run['logs'][-700:],'mapping':run['mapping'],'mapping_saved':run['mapping_saved'],
            'files':run['files'],'error':run['error'],'started':run['started'],
            'finished':run['finished'],'previews':previews}

def runner(run, start, stop):
    logger = logging.getLogger('studio.pipeline')
    handler = PerRunHandler(run)
    logger.addHandler(handler)
    try:
        for step in range(start, stop + 1):
            with LOCK:
                run['current'] = step
            execute_step(run['context'], step)
            with LOCK:
                run['completed'].add(step)
                run['files'] = list(run['context'].get('files', []))
                if step == 3 and not run['mapping_saved']:
                    run['mapping'] = suggested_dictionary(run['context'])
        with LOCK:
            run['current'] = None
            run['state'] = 'completed' if 6 in run['completed'] else ('checkpoint' if 3 in run['completed'] and not run['mapping_saved'] else 'ready')
            if run['state'] == 'completed':
                run['finished'] = datetime.now().isoformat(timespec='seconds')
    except Exception as exc:
        logger.exception('Step failed')
        with LOCK:
            run['error'] = str(exc)
            run['current'] = None
            run['state'] = 'failed'
    finally:
        logger.removeHandler(handler)

def get_run(run_id):
    run = RUNS.get(run_id)
    if run is None: abort(404)
    return run

@app.get('/')
def home():
    return render_template('dashboard.html', token=SHUTDOWN_TOKEN)

@app.get('/api/steps')
def steps():
    return jsonify([{'number':i+1,'title':title,'source':__import__('inspect').getsource(STEPS[i]), 'module':'modules/main_pipeline.py'} for i,title in enumerate(STEP_TITLES)])

@app.post('/api/runs')
def create_run():
    with LOCK:
        if any(r['state'] == 'running' for r in RUNS.values()):
            return jsonify(error='A step is running; wait for it to finish.'),409
        rid = datetime.now().strftime('%Y%m%d_%H%M%S') + '_' + secrets.token_hex(3)
        folder = ROOT / 'outputs' / rid
        folder.mkdir(parents=True, exist_ok=True)
        run = {'id':rid,'state':'ready','current':None,'completed':set(),'mapping':{},'mapping_saved':False,
               'context':{'output_dir':folder},'logs':[],'files':[],'error':None,
               'started':datetime.now().isoformat(timespec='seconds'),'finished':None}
        RUNS[rid] = run
        return jsonify(status(run)),201

@app.get('/api/runs')
def list_runs():
    with LOCK:
        return jsonify([{'id':r['id'],'state':r['state'],'completed':sorted(r['completed']),'started':r['started']} for r in reversed(list(RUNS.values()))])

@app.get('/api/runs/<rid>')
def get_status(rid):
    with LOCK:
        return jsonify(status(get_run(rid)))

@app.post('/api/runs/<rid>/step/<int:number>')
def run_step(rid, number):
    with LOCK:
        run = get_run(rid)
        if any(r['state']=='running' for r in RUNS.values()): return jsonify(error='A step is already running'),409
        expected = len(run['completed']) + 1
        if number != expected or not 1 <= number <= 6:
            return jsonify(error=f'Run step {expected} next. Steps are sequential.'),409
        if number >= 4 and not run['mapping_saved']:
            return jsonify(error='Save the dictionary before step 4.'),409
        run['state']='running'
        run['error']=None
        threading.Thread(target=runner,args=(run,number,number),daemon=True).start()
        return jsonify(status(run)),202

@app.post('/api/runs/<rid>/run-until-checkpoint')
def run_first_three(rid):
    with LOCK:
        run=get_run(rid)
        if any(r['state']=='running' for r in RUNS.values()): return jsonify(error='Already running'),409
        if run['completed']: return jsonify(error='Use individual step buttons for an existing run'),409
        run['state']='running'
        threading.Thread(target=runner,args=(run,1,3),daemon=True).start()
        return jsonify(status(run)),202

@app.post('/api/runs/<rid>/run-remaining')
def run_remaining(rid):
    with LOCK:
        run=get_run(rid)
        if any(r['state']=='running' for r in RUNS.values()): return jsonify(error='Already running'),409
        if run['completed'] != {1,2,3} or not run['mapping_saved']:
            return jsonify(error='Finish steps 1–3 and save the dictionary first'),409
        run['state']='running'
        threading.Thread(target=runner,args=(run,4,6),daemon=True).start()
        return jsonify(status(run)),202

@app.post('/api/runs/<rid>/dictionary')
def save_dictionary(rid):
    payload=request.get_json(silent=True) or {}
    mapping=payload.get('mapping')
    with LOCK:
        run=get_run(rid)
        if run['state']=='running' or 3 not in run['completed'] or 4 in run['completed']:
            return jsonify(error='Dictionary can only be edited after step 3 and before step 4'),409
        if not isinstance(mapping,dict): return jsonify(error='Dictionary must be a JSON object'),400
        required=set(run['context']['df']['segment'].unique())
        if set(mapping)!=required: return jsonify(error='Required keys: '+', '.join(sorted(required))),400
        try:
            values={str(k):float(v) for k,v in mapping.items()}
            if any(not math.isfinite(v) or not 0 <= v <= 100 for v in values.values()):
                raise ValueError('Values must be finite numbers from 0 to 100')
        except (ValueError,TypeError) as exc:
            return jsonify(error=str(exc)),400
        run['mapping']=values
        run['context']['mapping']=values
        run['mapping_saved']=True
        run['state']='ready'
        line=f"{datetime.now():%H:%M:%S} | INFO    | Dictionary saved; ready for step 4"
        run['logs'].append(line)
        with (ROOT/'logs'/(rid+'.log')).open('a',encoding='utf-8') as f: f.write(line+'\n')
        return jsonify(status(run))

@app.get('/api/runs/<rid>/files/<filename>')
def file_download(rid,filename):
    with LOCK:
        run=get_run(rid)
        if filename not in run['files']: abort(404)
    return send_from_directory(ROOT/'outputs'/rid,filename,as_attachment=True)

@app.get('/api/runs/<rid>/log')
def log_download(rid):
    with LOCK: get_run(rid)
    return send_from_directory(ROOT/'logs',rid+'.log',as_attachment=True)

@app.post('/api/shutdown')
def shutdown():
    if request.headers.get('X-Shutdown-Token') != SHUTDOWN_TOKEN: abort(403)
    with LOCK:
        if any(r['state']=='running' for r in RUNS.values()):
            return jsonify(error='Wait until the running step finishes'),409
    def terminate():
        time.sleep(.5)
        os.kill(os.getpid(),signal.SIGTERM)
    threading.Thread(target=terminate,daemon=True).start()
    return jsonify(message='Server stopping')

if __name__ == '__main__':
    app.run(host='127.0.0.1',port=5000,debug=False,threaded=True,use_reloader=False)
