"""File-producing reporting functions imported by main_pipeline."""
import json
from pathlib import Path

def export_reports(df, summary, mapping, output_dir):
    folder = Path(output_dir)
    folder.mkdir(parents=True, exist_ok=True)
    files=[]
    for filename, frame in [('portfolio.csv',df),('segment_summary.csv',summary)]:
        frame.to_csv(folder / filename, index=False)
        files.append(filename)
    (folder / 'dictionary.json').write_text(json.dumps(mapping, indent=2),encoding='utf-8')
    files.append('dictionary.json')
    return files
