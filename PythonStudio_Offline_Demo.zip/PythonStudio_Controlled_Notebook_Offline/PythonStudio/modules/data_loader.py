"""Dummy input generator; replace with bank-approved data loading."""
import pandas as pd

def load_portfolio():
    return pd.DataFrame([
        {'segment':'Corporate','exposure':1200000,'pd':0.018,'lgd':0.42},
        {'segment':'Retail','exposure':720000,'pd':0.032,'lgd':0.35},
        {'segment':'SME','exposure':450000,'pd':0.045,'lgd':0.48},
        {'segment':'Corporate','exposure':800000,'pd':0.012,'lgd':0.40},
    ])
