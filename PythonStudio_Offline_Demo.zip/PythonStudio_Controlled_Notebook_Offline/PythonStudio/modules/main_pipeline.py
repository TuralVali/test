"""Main module with six hardcoded sequential steps and a human dictionary checkpoint.

Steps 1-3 prepare and compute intermediate results. After step 3, the runner
pauses for a human-edited dictionary. Steps 4-6 continue using the same run data.
"""
import logging
import time
from .data_loader import load_portfolio
from .calculations import calculate_expected_loss, summarize
from .reporting import export_reports

log = logging.getLogger('studio.pipeline')

def step_1(context):
    log.info('STEP 1/6: Loading sample portfolio')
    context['df'] = load_portfolio()
    log.info('Loaded %d rows', len(context['df']))

def step_2(context):
    log.info('STEP 2/6: Validating required columns')
    required = {'segment','exposure','pd','lgd'}
    missing = required - set(context['df'].columns)
    if missing:
        raise ValueError(f'Missing required columns: {sorted(missing)}')
    log.info('All required columns are present')

def step_3(context):
    log.info('STEP 3/6: Calculating baseline expected loss')
    context['df'] = calculate_expected_loss(context['df'])
    log.info('Baseline expected loss: %.2f', context['df']['expected_loss'].sum())
    log.warning('Manual dictionary review required before STEP 4')

def suggested_dictionary(context):
    return {segment: 1.0 for segment in sorted(context['df']['segment'].unique())}

def step_4(context):
    log.info('STEP 4/6: Applying user-confirmed segment multipliers')
    mapping = context['mapping']
    context['df']['multiplier'] = context['df']['segment'].map(mapping)
    if context['df']['multiplier'].isna().any():
        raise ValueError('Dictionary is missing one or more portfolio segments')
    context['df']['adjusted_loss'] = context['df']['expected_loss'] * context['df']['multiplier']
    log.info('Adjusted loss: %.2f', context['df']['adjusted_loss'].sum())

def step_5(context):
    log.info('STEP 5/6: Aggregating results')
    context['summary'] = summarize(context['df'])
    context['summary']['adjusted_loss'] = context['df'].groupby('segment')['adjusted_loss'].sum().reindex(context['summary']['segment']).to_numpy()
    log.info('Created summary with %d segments', len(context['summary']))

def step_6(context):
    log.info('STEP 6/6: Writing output files')
    context['files'] = export_reports(context['df'], context['summary'], context['mapping'], context['output_dir'])
    log.info('Generated: %s', ', '.join(context['files']))

STEPS = [step_1,step_2,step_3,step_4,step_5,step_6]

def execute_step(context, number):
    if not 1 <= number <= 6:
        raise ValueError('Invalid step')
    log.info('Starting %s', STEPS[number-1].__name__)
    STEPS[number-1](context)
    time.sleep(0.65)  # Demonstration only; remove for real calculations.
    log.info('Completed step %s/6', number)
