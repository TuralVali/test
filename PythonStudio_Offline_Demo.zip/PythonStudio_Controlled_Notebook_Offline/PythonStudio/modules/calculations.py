"""Imported by the main pipeline to demonstrate cross-module calls."""

def calculate_expected_loss(df):
    result = df.copy()
    result['expected_loss'] = result['exposure'] * result['pd'] * result['lgd']
    return result

def summarize(df):
    return df.groupby('segment', as_index=False).agg(exposure=('exposure','sum'),expected_loss=('expected_loss','sum'))
