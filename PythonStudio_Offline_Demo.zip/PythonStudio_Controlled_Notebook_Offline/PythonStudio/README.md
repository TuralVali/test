# Python Studio — Controlled Notebook (Offline)

A local Windows Python 3.13 demonstration application. All input data are synthetic. No CDN or internet access is used by the HTML dashboard. The server binds to **127.0.0.1:5000 only**.

## Getting started

1. Extract the ZIP to a writable folder (avoid network drives with execution restrictions).
2. Confirm Python 3.13 is available (`py -3.13 --version`).
3. Ensure Flask and pandas are available **in the new virtual environment**. The launcher creates `.venv` automatically, then tries to install dependencies **only** from the local `wheels/` folder using `--no-index`. The ZIP does not contain third-party wheel packages.
4. Double-click **Start Python Studio.bat**. It waits for Flask to respond and opens your default browser.
5. The app opens at http://127.0.0.1:5000 . Keep the console open.
6. Use **New Run**, then execute cells 1, 2, 3. The app suggests dictionary multipliers. Edit and save them, then execute cells 4, 5, 6. Or use the two batch buttons.
7. Logs appear live on the right and are written to `logs/<run_id>.log`; generated files are saved under `outputs/<run_id>/`.
8. Use **Stop Server** in the dashboard when no step is running, or press Ctrl+C in the server console.

## Offline dependencies

The Python standard library includes `json`, `logging`, `pathlib`, and `venv`. Flask and pandas are third-party packages. Obtain **IT-approved Windows x64 CPython 3.13-compatible wheels, including transitive dependencies** (for example numpy, python-dateutil, pytz/tzdata, Werkzeug, Jinja2, click, itsdangerous, blinker, MarkupSafe, six where required), and place them in `wheels/`. The launcher uses no external package index. Confirm dependency versions are compatible with your approved interpreter.

**Testing shortcut only**: If the base Python 3.13 installation already has Flask and pandas and you accept using global packages, delete `.venv` and create it manually with `py -3.13 -m venv --system-site-packages .venv`. Then double-click the launcher. This is less isolated and less portable.

## Project layout

- `app.py`: local Flask API, in-memory run state, background step execution, output and log downloads.
- `modules/main_pipeline.py`: six hardcoded steps, importing `data_loader.py`, `calculations.py`, and `reporting.py`.
- `templates/dashboard.html`: offline notebook UI.
- `static/style.css`, `static/script.js`: visual theme and polling.
- `outputs/`, `logs/`: runtime artifacts.

## Notebook semantics and limitations

- Source code is **read-only** in the browser. Edit Python functions in the `.py` files and restart the server to change behavior.
- Steps must run in order. They share the same in-memory `context` dictionary, including pandas DataFrames.
- After step 3, the mapping is edited in HTML and saved to the shared context before step 4.
- Run state lives **in server memory**. Restarting the server loses active state and run history; generated files and logs remain on disk.
- The live logs use short-interval polling, not WebSockets. A log file is generated for every run with executed steps.
- This demo is **single-process and localhost-only**. Do not expose it to a network or use it for untrusted browser users. No arbitrary Python execution is accepted from the browser.
- No real bank data is included. For actual bank use, obtain required IT/security approvals and ensure file retention, sensitive data logging, access, and package provenance comply with policy.
- If a step fails, it is not marked completed; a failed step may leave partially modified in-memory data. For production, consider transactional steps or resetting the run.

## Integrating your real modules

Keep the six `step_N(context)` functions in `modules/main_pipeline.py`. Call your real functions from those steps. Save intermediate objects under `context` keys; do not rely on module-level globals. Change `suggested_dictionary(context)` and `/api/runs/<rid>/dictionary` validation to match your real mapping schema. Use `logging.getLogger('studio.pipeline')` for messages visible in the console. Output files should be created in `context['output_dir']` and their filenames recorded in `context['files']`.
