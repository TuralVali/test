Place IT-approved offline Python 3.13 Windows x64 wheel files here, including transitive dependencies of Flask and pandas. This demo ZIP intentionally does not bundle third-party packages.
