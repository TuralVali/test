@echo off
echo Open the dashboard and click Stop Server.
echo Alternatively, press Ctrl+C in the server console window.
pause
