@echo off
setlocal
cd /d "%~dp0"
title Python Studio - Local Notebook
echo ==========================================
echo    PYTHON STUDIO - OFFLINE NOTEBOOK
echo ==========================================
if not exist ".venv\Scripts\python.exe" (
    echo Creating Python 3.13 virtual environment...
    py -3.13 -m venv .venv
    if errorlevel 1 goto :error
)
set "PYTHON_EXE=%CD%\.venv\Scripts\python.exe"
echo Checking required libraries...
"%PYTHON_EXE%" -c "import flask, pandas"
if errorlevel 1 (
    echo Trying APPROVED OFFLINE wheels only...
    "%PYTHON_EXE%" -m pip install --no-index --find-links="%CD%\wheels" -r requirements.txt
    if errorlevel 1 (
       echo ERROR: Missing dependencies. Add IT-approved wheels to wheels folder.
       echo Or see README for system-site-packages option.
       goto :error
    )
)
echo Starting local server at http://127.0.0.1:5000
echo Keep this console open. Press Ctrl+C to stop.
start "" /min powershell -NoProfile -Command "$u='http://127.0.0.1:5000/';for($i=0;$i -lt 60;$i++){try{$r=Invoke-WebRequest -Uri $u -UseBasicParsing -TimeoutSec 2;if($r.StatusCode -eq 200){Start-Process $u;exit}}catch{};Start-Sleep -Seconds 1}"
"%PYTHON_EXE%" app.py
exit /b 0
:error
pause
exit /b 1
