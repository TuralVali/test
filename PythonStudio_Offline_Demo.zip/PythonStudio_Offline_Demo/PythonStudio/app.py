"""Offline localhost demo. Do not expose to the network without authentication."""
import atexit
import json
import logging
import os
from pathlib import Path
import secrets
import signal
import threading
import time
from datetime import datetime
from flask import Flask, jsonify, render_template, request, send_from_directory, abort
from modules.main_pipeline import execute_step, suggested_dictionary

ROOT = Path(__file__).resolve().parent
RUNS = ROOT / 'runs'
LOGS = ROOT / 'logs'
OUTPUTS = ROOT / 'outputs'
for p in (RUNS, LOGS, OUTPUTS): p.mkdir(exist_ok=True)

app = Flask(__name__)
app.json.sort_keys = False
RUN_LOCK = threading.RLock()
ACTIVE = {}
SHUTDOWN_TOKEN = secrets.token_urlsafe(32)

class RunLogHandler(logging.Handler):
    def __init__(self, run):
        super().__init__()
        self.run = run
        self.setFormatter(logging.Formatter('%(asctime)s | %(levelname)-7s | %(message)s', '%H:%M:%S'))
    def emit(self, record):
        try:
            line = self.format(record)
            with RUN_LOCK:
                self.run['logs'].append(line)
                with (LOGS / (self.run['id'] + '.log')).open('a', encoding='utf-8') as f:
                    f.write(line + '\n')
        except Exception:
            self.handleError(record)

def public_run(run):
    return {'id':run['id'],'status':run['status'],'step':run['step'],
            'logs':list(run['logs']), 'files':list(run['files']),
            'mapping':dict(run['mapping']), 'error':run['error'],
            'started':run['started'], 'finished':run['finished'],
            'rows':len(run['context'].get('df',[])),
            'total_loss':round(float(run['context']['df']['expected_loss'].sum()),2) if 'df' in run['context'] and 'expected_loss' in run['context']['df'] else None}

def work(run, start, end):
    logger = logging.getLogger('studio.pipeline')
    handler = RunLogHandler(run)
    logger.addHandler(handler)
    logger.setLevel(logging.INFO)
    try:
        for number in range(start,end+1):
            with RUN_LOCK:
                if run['status'] != 'running': return
            execute_step(run['context'],number)
            with RUN_LOCK:
                run['step'] = number
        with RUN_LOCK:
            if end == 3:
                run['mapping'] = suggested_dictionary(run['context'])
                run['status'] = 'waiting'
            else:
                run['status'] = 'completed'
                run['finished'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                run['files'] = list(run['context'].get('files',[]))
    except Exception as exc:
        logger.exception('Execution failed')
        with RUN_LOCK:
            run['error'] = str(exc)
            run['status'] = 'failed'
            run['finished'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    finally:
        logger.removeHandler(handler)

@app.get('/')
def home():
    return render_template('dashboard.html', shutdown_token=SHUTDOWN_TOKEN)

@app.post('/api/runs')
def start_run():
    with RUN_LOCK:
        if any(r['status'] in ('running','waiting') for r in ACTIVE.values()):
            return jsonify(error='Finish the active pipeline before starting another.'),409
        run_id = datetime.now().strftime('%Y%m%d_%H%M%S') + '_' + secrets.token_hex(3)
        folder = OUTPUTS / run_id
        folder.mkdir(parents=True,exist_ok=True)
        run = {'id':run_id,'status':'running','step':0,'logs':[],'files':[],
               'mapping':{},'error':None,'started':datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
               'finished':None,'context':{'output_dir':folder}}
        ACTIVE[run_id]=run
        threading.Thread(target=work,args=(run,1,3),daemon=True).start()
    return jsonify(public_run(run)),201

@app.get('/api/runs')
def list_runs():
    with RUN_LOCK:
        return jsonify([public_run(r) for r in reversed(list(ACTIVE.values()))])

@app.get('/api/runs/<run_id>')
def get_run(run_id):
    with RUN_LOCK:
        run=ACTIVE.get(run_id)
        if not run: abort(404)
        return jsonify(public_run(run))

@app.post('/api/runs/<run_id>/continue')
def continue_run(run_id):
    payload=request.get_json(silent=True) or {}
    mapping=payload.get('mapping')
    with RUN_LOCK:
        run=ACTIVE.get(run_id)
        if not run: abort(404)
        if run['status']!='waiting': return jsonify(error='Run is not awaiting dictionary approval'),409
        if not isinstance(mapping,dict): return jsonify(error='Dictionary must be a JSON object'),400
        required=set(run['context']['df']['segment'].unique())
        if set(mapping)!=required:
            return jsonify(error='Dictionary keys must match segments: '+', '.join(sorted(required))),400
        try:
            clean={str(k):float(v) for k,v in mapping.items()}
            if any(not (0 <= v <= 100) or not __import__('math').isfinite(v) for v in clean.values()):
                raise ValueError('Multipliers must be finite numbers between 0 and 100')
        except (ValueError,TypeError) as exc:
            return jsonify(error=str(exc)),400
        run['mapping']=clean
        run['context']['mapping']=clean
        run['status']='running'
        threading.Thread(target=work,args=(run,4,6),daemon=True).start()
        return jsonify(public_run(run))

@app.get('/api/runs/<run_id>/files/<filename>')
def download(run_id,filename):
    with RUN_LOCK:
        run=ACTIVE.get(run_id)
        if not run or filename not in run['files']: abort(404)
    return send_from_directory(OUTPUTS / run_id,filename,as_attachment=True)

@app.get('/api/runs/<run_id>/log')
def download_log(run_id):
    with RUN_LOCK:
        if run_id not in ACTIVE: abort(404)
    return send_from_directory(LOGS,run_id+'.log',as_attachment=True)

@app.post('/api/shutdown')
def shutdown():
    if request.headers.get('X-Shutdown-Token') != SHUTDOWN_TOKEN:
        abort(403)
    with RUN_LOCK:
        if any(r['status']=='running' for r in ACTIVE.values()):
            return jsonify(error='Cannot stop while a calculation is running'),409
    def stop():
        time.sleep(0.5)
        os.kill(os.getpid(),signal.SIGTERM)
    threading.Thread(target=stop,daemon=True).start()
    return jsonify(message='Server stopping')

if __name__ == '__main__':
    app.run(host='127.0.0.1',port=5000,debug=False,threaded=True,use_reloader=False)
