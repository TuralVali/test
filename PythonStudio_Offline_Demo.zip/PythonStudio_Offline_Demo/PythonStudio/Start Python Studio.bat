@echo off
setlocal
cd /d "%~dp0"
title Python Studio - Local Offline Launcher
echo ==========================================
echo         PYTHON STUDIO - OFFLINE
echo ==========================================
echo.
if not exist ".venv\Scripts\python.exe" (
  echo Creating Python 3.13 environment...
  py -3.13 -m venv .venv
  if errorlevel 1 (
    echo ERROR: Python 3.13 or venv not available.
    pause
    exit /b 1
  )
)
set "PYTHON_EXE=%CD%\.venv\Scripts\python.exe"
"%PYTHON_EXE%" -c "import flask, pandas"
if errorlevel 1 (
  echo Dependencies not found. Attempting offline installation from wheels\
  "%PYTHON_EXE%" -m pip install --no-index --find-links="%CD%\wheels" -r requirements.txt
  if errorlevel 1 (
    echo.
    echo ERROR: Offline packages missing or incompatible.
    echo Copy approved Python 3.13 Windows wheels and all dependencies into wheels\
    echo See README.md for alternatives.
    pause
    exit /b 1
  )
)
echo Dependencies ready.
echo Opening dashboard when server is ready...
start "" /min powershell -NoProfile -ExecutionPolicy Bypass -Command "$u='http://127.0.0.1:5000/';for($i=0;$i -lt 60;$i++){try{$r=Invoke-WebRequest -Uri $u -UseBasicParsing -TimeoutSec 2;if($r.StatusCode -eq 200){Start-Process $u;exit}}catch{};Start-Sleep -Seconds 1}"
echo.
echo The Flask server runs in THIS window. Keep it open.
echo Stop from the dashboard or close with Ctrl+C.
"%PYTHON_EXE%" app.py
echo.
echo Python Studio has stopped.
pause
