# Python Studio — offline Windows demo

A local, dark electric-blue dashboard demonstrating a **six-step main Python pipeline**, imported helper modules, live logs, generated CSV/JSON files, and a **human-editable dictionary checkpoint** between steps 3 and 4.

## Quick start (Windows / Python 3.13)

1. Extract the ZIP to a normal folder (do not launch directly from ZIP).
2. Double-click `Start Python Studio.bat`.
3. The launcher creates `.venv`, checks Flask and pandas, starts Flask at `http://127.0.0.1:5000`, and opens your default browser once ready.
4. Click **Start Pipeline**. Steps 1–3 run automatically, then pause. Adjust the numeric values in the **Dictionary Editor** and click **Save & Continue**. Steps 4–6 run automatically.
5. Inspect logs on the right. Download generated CSV and JSON reports and the log. Click **Stop Server** when finished.

## No internet access / dependencies

The ZIP includes application source and assets, **not** Python, Flask, pandas, or wheel files. Python 3.13 must already be installed. A new `.venv` is isolated, so even if Flask and pandas are installed in your base Python they might not be available in it.

Choose one of these approved approaches:

- **Preferred for sharing:** IT supplies a complete wheelhouse of compatible **Windows x64 / Python 3.13** wheels for `Flask`, `pandas`, and all their transitive dependencies. Place the wheel files into `wheels/`. The launcher installs with `--no-index`, never connecting to the internet.
- **For local testing when packages are already installed in the base interpreter:** before first launch, create the environment using `py -3.13 -m venv --system-site-packages .venv`. Then launch the batch file. This option is less isolated and depends on the machine's packages.

Do not install unapproved third-party packages on bank computers. `json`, `logging`, `pathlib`, and other Python standard-library modules need no wheels.

## Modules and stages

- `modules/main_pipeline.py` imports `data_loader.py`, `calculations.py`, and `reporting.py`.
- Steps 1–3: load sample DataFrame, validate columns, calculate baseline expected loss.
- **Checkpoint:** UI shows a suggested dictionary keyed by portfolio segment. Edit values (0–100) and confirm.
- Steps 4–6: apply multipliers, summarize, and write output files.
- `app.py` runs the steps in a background thread and polls status/logs from the browser every 800ms.
- `logs/<run_id>.log`, `outputs/<run_id>/` hold generated artifacts. Runs are held in memory and disappear from dashboard history on restart; saved files remain.

## Notes and limitations

- This is a **single-user, local-only sample**, bound to `127.0.0.1:5000`. Do **not** expose it to other computers or deploy as a production banking service.
- Flask's built-in development server is used for localhost demo only.
- Log updates are near-live via polling. The log handler captures `logging` from `studio.pipeline` (not arbitrary third-party loggers).
- The dashboard's Stop Server button sends a per-startup secret and refuses to stop while a step is running. It is suitable only for this localhost demo.
- Each run is independent and has a unique output directory. Only one active or awaiting-approval run is permitted at a time.
- Dictionary keys are fixed to generated segments for this sample; values can be edited. This prevents accidental missing segment mappings. A general key-add/delete editor can be added when adapting your actual module.
- The UI uses locally bundled CSS and JavaScript. There are no external CDNs, fonts, analytics, or APIs.
- The batch file relies on Windows PowerShell to open the browser after the server becomes ready. If PowerShell is blocked by bank policy, manually open `http://127.0.0.1:5000`.

## Manual start

```bat
py -3.13 -m venv --system-site-packages .venv
.venv\Scripts\python.exe app.py
```

Open `http://127.0.0.1:5000`.

## Security

Use synthetic sample data only. Before adapting to bank data, review output/log retention, access controls, approved directories, package provenance, and bank policies. Avoid logging sensitive records or secrets.
