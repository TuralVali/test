@echo off
echo Open the dashboard and click "Stop Server".
echo Alternatively, use Ctrl+C in the Python Studio server console.
echo This file intentionally does not terminate arbitrary Python processes.
pause
