import sys
from pathlib import Path
from PySide6.QtCore import Qt, QObject, Slot, Signal, QUrl
from PySide6.QtWidgets import QApplication, QMainWindow
from PySide6.QtWebEngineWidgets import QWebEngineView
from PySide6.QtWebChannel import QWebChannel

ROOT = Path(__file__).resolve().parent
class Bridge(QObject):
    event = Signal(str)
    def __init__(self):
        super().__init__()
        self.state = {'df': None, 'config': {'threshold': 0.65, 'dataset': 'demo'}, 'metrics': {}, 'summary': None}
    @Slot(int)
    def runStep(self, step):
        try:
            if step == 1:
                self.state['df'] = [{'id': i, 'category': 'ABCD'[i%4], 'value': round(100 + (i*17)%137 + i*.13,2)} for i in range(1,501)]
                message = 'Loaded 500 demonstration records'
            elif step == 2:
                if self.state['df'] is None: raise ValueError('Run Load Data first')
                for r in self.state['df']: r['score'] = round(r['value']/250, 3)
                message = 'Processed 500 records and calculated scores'
            elif step == 3:
                if not self.state['df'] or 'score' not in self.state['df'][0]: raise ValueError('Run steps 1 and 2 first')
                import statistics
                self.state['metrics'] = {'mean': round(statistics.mean(r['value'] for r in self.state['df']),2), 'rows': len(self.state['df'])}
                message = f"Analysis complete: mean={self.state['metrics']['mean']}"
            elif step == 4:
                if not self.state['metrics']: raise ValueError('Run step 3 first')
                message = 'Visualization data ready'
            elif step == 5:
                if not self.state['metrics']: raise ValueError('Run step 3 first')
                self.state['summary'] = dict(self.state['metrics'])
                message = 'Report summary generated'
            elif step == 6:
                if self.state['summary'] is None: raise ValueError('Run step 5 first')
                import json
                p = ROOT / 'demo_results.json'
                p.write_text(json.dumps(self.state['summary'], indent=2), encoding='utf-8')
                message = f'Exported {p.name}'
            else: raise ValueError('Invalid step')
            import json
            self.event.emit(json.dumps({'step':step,'ok':True,'message':message,'state':{'rows':len(self.state['df'] or []),'metrics':self.state['metrics'],'preview':(self.state['df'] or [])[:5]}}))
        except Exception as exc:
            import json
            self.event.emit(json.dumps({'step':step,'ok':False,'message':str(exc)}))
    @Slot(str)
    def saveConfig(self, raw):
        import json
        try:
            data=json.loads(raw)
            if not isinstance(data,dict): raise ValueError('Configuration must be a JSON object')
            self.state['config']=data
            self.event.emit(json.dumps({'ok':True,'message':'Configuration saved'}))
        except Exception as exc: self.event.emit(json.dumps({'ok':False,'message':f'Invalid configuration: {exc}'}))

class Studio(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('Python Studio C2 | Holographic Developer')
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.Window)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.view=QWebEngineView(self)
        self.view.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.view.page().setBackgroundColor(Qt.GlobalColor.transparent)
        self.setCentralWidget(self.view)
        self.channel=QWebChannel(self.view.page())
        self.bridge=Bridge()
        self.channel.registerObject('bridge',self.bridge)
        self.view.page().setWebChannel(self.channel)
        self.view.load(QUrl.fromLocalFile(str(ROOT/'index.html')))
        self.resize(1500,860)
    def keyPressEvent(self,e):
        if e.key()==Qt.Key.Key_Escape: self.close()
        super().keyPressEvent(e)

if __name__=='__main__':
    app=QApplication(sys.argv)
    win=Studio();win.show()
    sys.exit(app.exec())
