# Python Studio C2 — Holographic Developer

An independent alternative to the existing B and C themes. This prototype follows the uploaded developer-studio reference: electric-blue floating panels, code explorer/editor, six run steps, interactive 3D-style dependency graph, logs, variables, data preview and plots.

## Launch on Windows

```bash
python -m pip install -r requirements.txt
python app.py
```

The app uses a transparent frameless Qt WebEngine window. Press Esc to exit. The header is styled as a window bar, but native drag/minimize controls are not implemented in this prototype. Transparency/compositing may differ across Windows and graphics drivers.

You can also open `index.html` in a normal browser for **visual preview only**; the Python execution bridge is unavailable there, and the background will show the browser rather than desktop wallpaper.

## Included behavior

- Six **working demonstration** steps backed by Python, with shared state and prerequisite checks.
- JSON configuration validation and updates to the Python state.
- Live log messages, variables/metrics and data-preview updates.
- Interactive canvas dependency graph with drag-to-orbit, wheel zoom, and clickable node selection. This graph is **illustrative**, not automatically extracted from a repository.
- Editable code panel for interface prototyping. It is **not** an arbitrary Python interpreter and edits are not executed by the step engine.
- No internet or CDN assets needed after PySide6 is installed.

## Scope and security

The step engine is deliberately fixed and safe: it does not execute arbitrary editor text or load external files. To integrate a real pipeline, replace the demonstration functions in `Bridge.runStep`, keeping the same events. This is a functional prototype, not a full IDE.
