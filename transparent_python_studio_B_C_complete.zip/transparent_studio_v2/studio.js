(()=>{
const $=s=>document.querySelector(s), hologram=document.body.classList.contains('hologram');
let bridge=null,runs=0;
if(window.qt && window.QWebChannel){new QWebChannel(qt.webChannelTransport, channel=>{bridge=channel.objects.python;});}
const names=['Load source data','Validate inputs','Transform portfolio','Update parameters','Run calculations','Export results'];
const descriptions=['Import local files','Schema and data checks','Apply business mappings','Modify shared dictionary','Execute Python pipeline','Save output and reports'];
const steps=$('#steps');
names.forEach((name,i)=>{
let el=document.createElement('div');el.className=hologram?'holo-step':'step';
el.innerHTML=hologram?`<span class="step-index">0${i+1}</span><span class="holo-node">⬡</span><div class="step-text"><b>${name.toUpperCase()}</b><small>${descriptions[i].toUpperCase()}</small></div><span class="step-status" id="status${i}">STANDBY</span><button data-step="${i+1}">▶ EXECUTE</button>`:`<span class="step-icon">${['▣','◈','⌘','{ }','⚡','↗'][i]}</span><div class="step-text"><b>${name}</b><small>${descriptions[i]}</small></div><span class="step-status" id="status${i}">Ready</span><button data-step="${i+1}">Run →</button>`;
steps.append(el);
});
const stamp=()=>new Date().toLocaleTimeString('en-GB',{hour12:false});
function log(message,error=false){let line=document.createElement('div');line.className=error?'log-error':'';let t=document.createElement('span');t.textContent=stamp();line.append(t,document.createTextNode(' '+message));$('#console').append(line);$('#console').scrollTop=$('#console').scrollHeight;}
function validate(){try{let obj=JSON.parse($('#config').value);if(!obj||Array.isArray(obj)||typeof obj!=='object')throw Error('Root must be an object');$('#jsonState').textContent=hologram?'● JSON VALID':'● Valid JSON';log('Configuration validated');return true;}catch(e){$('#jsonState').textContent='✕ Invalid JSON';log('JSON error: '+e.message,true);return false;}}
$('#validate').onclick=validate;$('#clear').onclick=()=>{$('#console').innerHTML='';};
steps.addEventListener('click',e=>{let btn=e.target.closest('button[data-step]');if(!btn)return;if(!validate())return;let index=Number(btn.dataset.step)-1,st=$('#status'+index);btn.disabled=true;st.textContent=hologram?'RUNNING':'Running';$('#overall').textContent=hologram?'ACTIVE':'Active';log('Executing module 0'+(index+1)+' — '+names[index]);
const finish=result=>{let data;try{data=JSON.parse(result)}catch{data={ok:false,message:result}};st.textContent=data.ok?(hologram?'COMPLETE':'Done'):(hologram?'ERROR':'Error');st.classList.toggle('done',data.ok);log(data.message,!data.ok);runs++;$('#runCount').textContent=String(runs).padStart(2,'0');$('#overall').textContent=hologram?'READY':'Ready';btn.disabled=false;};
if(bridge){bridge.run_step(String(index+1),$('#config').value,finish);}else{setTimeout(()=>finish(JSON.stringify({ok:true,message:'Module 0'+(index+1)+' completed (browser preview / demo)'})),420);}
});
document.querySelectorAll('[data-action="close"]').forEach(b=>b.onclick=()=>{if(bridge)bridge.close_app();else log('Close from desktop window');});
document.querySelectorAll('[data-action="minimize"]').forEach(b=>b.onclick=()=>{if(bridge)bridge.minimize();else log('Minimize from desktop window');});
if($('#clock')){let update=()=>$('#clock').textContent=stamp();update();setInterval(update,1000);}
})();
