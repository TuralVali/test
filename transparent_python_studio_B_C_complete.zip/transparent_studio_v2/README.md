# Transparent Python Studio — Version B and Version C

Two **different** local Windows desktop UI prototypes. Both use the same demonstration Python bridge.

- **B / Glass** (`glass.html`): floating rounded frosted-glass cards, soft cyan/pink accents, charts, workflow and JSON editor. Inspired by the reference screenshot.
- **C / Hologram** (`hologram.html`): electric-blue wireframe HUD, angular panels, execution matrix, animated radar and console.

## Windows setup

```powershell
py -m pip install -r requirements.txt
py app.py b
py app.py c
```

`app.py` uses a borderless, transparent, always-on-top PySide6 WebEngine window. For moving a borderless window, use Alt+Space then Move (Windows), or add a native draggable title region to the launcher. Close with × in the top-right, or Alt+F4.

## Preview in a browser

Open `glass.html` or `hologram.html` in Chrome. **Browsers cannot reveal the actual desktop behind a browser window**. Add `preview` to the `<body>` class to see the demo gradient behind the cards, or use the supplied screenshots. The real desktop transparency needs the PySide6 launcher.

## Functionality

Six module buttons, shared editable JSON, validation, execution log, run counter. The Python bridge **only returns a demo result**; it does not execute external modules. Replace `Bridge.run_step` in `app.py` with validated calls to your local Python modules. Do not evaluate arbitrary strings as Python.

## Glass blur note

CSS `backdrop-filter` blurs web-layer content, but **does not reliably blur the Windows desktop wallpaper behind a transparent Qt WebEngine window**. Native Windows Acrylic/Mica or a separately composited background is required for that exact effect. Actual window transparency and frosted desktop blur are different features. Appearance varies with Windows and GPU.
