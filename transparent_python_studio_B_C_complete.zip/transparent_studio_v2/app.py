import sys
from pathlib import Path
from PySide6.QtCore import Qt, QObject, Slot, Signal, QUrl
from PySide6.QtGui import QColor
from PySide6.QtWidgets import QApplication, QMainWindow
from PySide6.QtWebEngineWidgets import QWebEngineView
from PySide6.QtWebChannel import QWebChannel
from steps import StudioEngine

ROOT = Path(__file__).resolve().parent
class Bridge(QObject):
    def __init__(self, window):
        super().__init__()
        self.window = window
        self.engine = StudioEngine(lambda message: None)

    @Slot(str, str, result=str)
    def run_step(self, number, config):
        import json
        try:
            parsed = json.loads(config)
            if not isinstance(parsed, dict):
                raise ValueError("Configuration must be a JSON object")
            self.engine.config = parsed
            index = int(number)
            if index not in range(1, 7):
                raise ValueError("Step must be between 1 and 6")
            functions = [self.engine.load_data, self.engine.validate,
                         self.engine.transform, self.engine.model,
                         self.engine.aggregate, self.engine.export]
            result = functions[index - 1]()
            self.engine.state[f"step_{index}"] = result
            return json.dumps({"ok": True, "message": f"Step {index} completed: {result}"}, default=str)
        except Exception as exc:
            return json.dumps({"ok": False, "message": f"Step {number} failed: {exc}"})

    @Slot()
    def close_app(self):
        self.window.close()

    @Slot()
    def minimize(self):
        self.window.showMinimized()

class Window(QMainWindow):
    def __init__(self, theme):
        super().__init__()
        self.setWindowTitle('Python Studio — '+theme.title())
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.Window)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.resize(1370, 850)
        self.web=QWebEngineView(self)
        self.web.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.web.page().setBackgroundColor(QColor(0,0,0,0))
        self.setCentralWidget(self.web)
        self.channel=QWebChannel(self.web.page())
        self.bridge=Bridge(self)
        self.channel.registerObject('python', self.bridge)
        self.web.page().setWebChannel(self.channel)
        self.web.load(QUrl.fromLocalFile(str(ROOT / (theme+'.html'))))

if __name__=='__main__':
    theme=sys.argv[1].lower() if len(sys.argv)>1 else 'glass'
    if theme in ('b','glass'): theme='glass'
    elif theme in ('c','hologram'): theme='hologram'
    else: raise SystemExit('Use: python app.py glass OR python app.py hologram')
    app=QApplication(sys.argv)
    w=Window(theme); w.show()
    sys.exit(app.exec())
